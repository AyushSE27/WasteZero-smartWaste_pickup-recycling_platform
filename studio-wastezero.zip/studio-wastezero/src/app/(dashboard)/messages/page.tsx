"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Send, MessageSquare } from "lucide-react";
import { users, messages as initialMessages } from "@/lib/data";
import type { User, Message } from "@/lib/types";

export default function MessagesPage() {
    const { user: currentUser, loading } = useAuth();
    const [contacts, setContacts] = useState<User[]>([]);
    const [selectedContact, setSelectedContact] = useState<User | null>(null);
    const [allMessages, setAllMessages] = useState<Message[]>(initialMessages);
    const [newMessage, setNewMessage] = useState('');

    useEffect(() => {
        if (currentUser) {
            setContacts(users.filter(u => u.role !== 'admin' && u.id !== currentUser.id).slice(0, 7));
        }
    }, [currentUser]);


    if (loading || !currentUser) {
        return (
            <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
                <p className="text-muted-foreground">Loading your messages...</p>
            </div>
        )
    }

    const getInitials = (name: string) => {
        return name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase();
    };

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newMessage.trim() || !selectedContact) return;

        const message: Message = {
            id: `msg-${Date.now()}`,
            senderId: currentUser.id,
            receiverId: selectedContact.id,
            content: newMessage.trim(),
            timestamp: new Date().toISOString(),
        };

        setAllMessages(prev => [...prev, message]);
        setNewMessage('');
    }
    
    const displayedMessages = allMessages.filter(msg => 
        (msg.senderId === currentUser.id && msg.receiverId === selectedContact?.id) ||
        (msg.senderId === selectedContact?.id && msg.receiverId === currentUser.id)
    ).sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    return (
        <div className="h-[calc(100vh-10rem)]">
            <h1 className="text-3xl font-bold font-headline mb-4">Messages</h1>
            <Card className="h-full grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4">
                <div className="md:col-span-1 lg:col-span-1 border-r h-full flex flex-col">
                    <div className="p-4 border-b">
                        <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input placeholder="Search contacts..." className="pl-8" />
                        </div>
                    </div>
                    <div className="flex-grow overflow-auto">
                        {contacts.map(contact => (
                            <div 
                                key={contact.id} 
                                className={`flex items-center gap-3 p-3 cursor-pointer hover:bg-secondary transition-colors ${contact.id === selectedContact?.id ? 'bg-secondary' : ''}`} 
                                onClick={() => setSelectedContact(contact)}
                            >
                                <Avatar>
                                    <AvatarImage src={contact.avatarUrl} alt={contact.name} />
                                    <AvatarFallback>{getInitials(contact.name)}</AvatarFallback>
                                </Avatar>
                                <div className="flex-grow">
                                    <p className="font-semibold">{contact.name}</p>
                                    <p className="text-sm text-muted-foreground truncate">Click to view messages</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="md:col-span-2 lg:col-span-3 h-full flex flex-col">
                    {selectedContact ? (
                        <>
                            <div className="flex items-center gap-3 p-4 border-b">
                                <Avatar>
                                    <AvatarImage src={selectedContact.avatarUrl} alt={selectedContact.name} />
                                    <AvatarFallback>{getInitials(selectedContact.name)}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <p className="font-semibold text-lg">{selectedContact.name}</p>
                                    <p className="text-sm text-green-500 flex items-center gap-1"><span className="h-2 w-2 bg-green-500 rounded-full"></span>Online</p>
                                </div>
                            </div>
                            <div className="flex-grow p-4 overflow-auto bg-slate-50 dark:bg-slate-900 space-y-4">
                                {displayedMessages.length > 0 ? displayedMessages.map(msg => (
                                    <div key={msg.id} className={`flex ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                                        <div className={`max-w-xs lg:max-w-md p-3 rounded-xl ${msg.senderId === currentUser.id ? 'bg-primary text-primary-foreground' : 'bg-background shadow-sm'}`}>
                                            <p>{msg.content}</p>
                                            <p className={`text-xs mt-1 text-right ${msg.senderId === currentUser.id ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                        </div>
                                    </div>
                                )) : (
                                    <div className="flex items-center justify-center h-full">
                                        <p className="text-muted-foreground">No messages yet. Say hello!</p>
                                    </div>
                                )}
                            </div>
                            <form onSubmit={handleSendMessage} className="p-4 border-t bg-background">
                                <div className="relative">
                                    <Input 
                                        placeholder="Type a message..." 
                                        className="pr-12" 
                                        value={newMessage}
                                        onChange={(e) => setNewMessage(e.target.value)}
                                        autoComplete="off"
                                    />
                                    <Button type="submit" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8" disabled={!newMessage.trim()}>
                                        <Send className="h-4 w-4" />
                                    </Button>
                                </div>
                            </form>
                        </>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center p-4">
                             <MessageSquare className="h-16 w-16 text-muted-foreground/50 mb-4" />
                            <p className="text-muted-foreground font-semibold text-lg">Select a contact to start messaging</p>
                            <p className="text-muted-foreground text-sm">Your conversations will appear here.</p>
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
}