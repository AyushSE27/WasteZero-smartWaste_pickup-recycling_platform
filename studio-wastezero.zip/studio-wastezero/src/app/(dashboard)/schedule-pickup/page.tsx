"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, Truck } from "lucide-react";
import { format } from "date-fns";
import type { WasteType } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

const wasteTypes: WasteType[] = ['plastic', 'organic', 'e-waste', 'metal', 'paper', 'glass', 'textile'];

export default function SchedulePickupPage() {
  const [date, setDate] = useState<Date | undefined>();
  const [wasteType, setWasteType] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const { toast } = useToast();

  // Set initial date on client to avoid hydration mismatch
  useEffect(() => {
    setDate(new Date());
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !wasteType || !address) {
        toast({
            title: "Missing Information",
            description: "Please fill out the waste type, date, and address.",
            variant: "destructive"
        });
        return;
    }
    toast({
        title: "Pickup Scheduled!",
        description: "Your waste pickup has been successfully scheduled."
    });
    // Reset form
    setDate(new Date());
    setWasteType('');
    setAddress('');
    setNotes('');
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">Schedule a Pickup</h1>
        <p className="text-muted-foreground">Arrange for your waste to be collected by our team.</p>
      </div>

      <Card>
        <CardHeader>
            <CardTitle>Pickup Details</CardTitle>
            <CardDescription>Please provide the details for your waste pickup.</CardDescription>
        </CardHeader>
        <CardContent>
            <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="waste-type">Waste Type</Label>
                        <Select value={wasteType} onValueChange={setWasteType} required>
                            <SelectTrigger id="waste-type">
                                <SelectValue placeholder="Select a waste type" />
                            </SelectTrigger>
                            <SelectContent>
                                {wasteTypes.map(type => (
                                    <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="date">Pickup Date</Label>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button
                                variant={"outline"}
                                className="w-full justify-start text-left font-normal"
                                >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {date ? format(date, "PPP") : <span>Pick a date</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar
                                mode="single"
                                selected={date}
                                onSelect={setDate}
                                disabled={(date) => date < new Date(new Date().setDate(new Date().getDate() - 1))}
                                initialFocus
                                />
                            </PopoverContent>
                        </Popover>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="address">Pickup Address</Label>
                    <Input id="address" placeholder="e.g., 123 Green St, Eco City" value={address} onChange={(e) => setAddress(e.target.value)} required />
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes (optional)</Label>
                    <Input id="notes" placeholder="e.g., Leave by the front gate" value={notes} onChange={(e) => setNotes(e.target.value)} />
                </div>
                <div className="flex justify-end">
                    <Button type="submit">
                        <Truck className="mr-2 h-4 w-4" />
                        Confirm Pickup
                    </Button>
                </div>
            </form>
        </CardContent>
      </Card>
    </div>
  );
}
