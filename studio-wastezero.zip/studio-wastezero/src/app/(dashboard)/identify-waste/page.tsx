
"use client";

import { useState } from "react";
import Image from "next/image";
import { wasteItemIdentifierAndGuide } from "@/ai/flows/waste-item-identifier-and-guide";
import type { WasteItemIdentifierAndGuideOutput } from "@/ai/flows/waste-item-identifier-and-guide";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Upload, Type, Loader2, Recycle, Trash2, FileWarning, Sparkles } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import type { VariantProps } from "class-variance-authority";
import { badgeVariants } from "@/components/ui/badge";

function IdentificationResult({ result }: { result: WasteItemIdentifierAndGuideOutput }) {
  const getResultIcon = (isRecyclable: boolean, wasteType: string) => {
    if (wasteType === 'hazardous') return <FileWarning className="h-10 w-10 text-destructive" />;
    if (isRecyclable) return <Recycle className="h-10 w-10 text-primary" />;
    return <Trash2 className="h-10 w-10 text-muted-foreground" />;
  };

  const getBadgeVariant = (isRecyclable: boolean, wasteType: string): VariantProps<typeof badgeVariants>["variant"] => {
    if (wasteType === 'hazardous') return "destructive";
    if (isRecyclable) return "default";
    return "secondary";
  }

  return (
    <Card className="mt-8 animate-in fade-in-50">
      <CardHeader>
        <div className="flex items-center gap-4">
          <Sparkles className="h-6 w-6 text-primary" />
          <CardTitle className="font-headline">Identification Result</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
            <div className="flex-shrink-0 bg-secondary p-4 rounded-full">
                {getResultIcon(result.isRecyclable, result.wasteType)}
            </div>
            <div className="flex-grow w-full">
                <div className="flex justify-between items-baseline mb-2">
                    <h3 className="text-xl font-semibold capitalize">{result.wasteType === 'e-waste' ? 'E-Waste' : result.wasteType}</h3>
                    <Badge variant={getBadgeVariant(result.isRecyclable, result.wasteType)}>
                      {result.wasteType === 'hazardous' ? 'Hazardous' : result.isRecyclable ? "Recyclable" : "Non-Recyclable"}
                    </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-1">Confidence: {result.identificationConfidence.toFixed(0)}%</p>
                <Progress value={result.identificationConfidence} className="w-full h-2" />
            </div>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Disposal Instructions</h4>
          <p className="text-muted-foreground whitespace-pre-wrap leading-relaxed">{result.disposalInstructions}</p>
        </div>
      </CardContent>
    </Card>
  );
}


export default function IdentifyWastePage() {
  const [inputMode, setInputMode] = useState<"image" | "text">("image");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [description, setDescription] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<WasteItemIdentifierAndGuideOutput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) { // 4MB limit for Gemini
        toast({ title: "Image too large", description: "Please upload an image smaller than 4MB.", variant: "destructive" });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      let output: WasteItemIdentifierAndGuideOutput;
      if (inputMode === 'image' && imageUrl) {
        output = await wasteItemIdentifierAndGuide({ wasteImage: imageUrl });
      } else if (inputMode === 'text' && description) {
        output = await wasteItemIdentifierAndGuide({ wasteDescription: description });
      } else {
        toast({ title: "Input missing", description: "Please provide an image or a description.", variant: "destructive" });
        setIsLoading(false);
        return;
      }
      setResult(output);
    } catch (err) {
      console.error(err);
      const errorMessage = "Failed to identify the item. The AI model may be temporarily unavailable. Please try again later.";
      setError(errorMessage);
      toast({ title: "An error occurred", description: errorMessage, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setImageUrl(null);
    setDescription("");
    setResult(null);
    setError(null);
    const fileInput = document.getElementById('waste-image') as HTMLInputElement;
    if(fileInput) fileInput.value = '';
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">Identify Waste Item</h1>
        <p className="text-muted-foreground">Not sure how to dispose of an item? Let our AI assistant help you.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Submit an Item for Identification</CardTitle>
          <CardDescription>Upload a photo or provide a description of your waste item.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={inputMode} onValueChange={(value) => setInputMode(value as "image" | "text")} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="image"><Upload className="mr-2 h-4 w-4" /> Upload Image</TabsTrigger>
              <TabsTrigger value="text"><Type className="mr-2 h-4 w-4" /> Text Description</TabsTrigger>
            </TabsList>
            <TabsContent value="image" className="mt-6">
              <div className="space-y-2">
                <Label htmlFor="waste-image">Image File</Label>
                <Input id="waste-image" type="file" accept="image/*" onChange={handleImageChange} disabled={isLoading} />
                 <p className="text-xs text-muted-foreground">Max file size: 4MB.</p>
              </div>
              {imageUrl && (
                <div className="mt-4 relative border rounded-md p-2 bg-secondary/50 max-w-sm mx-auto">
                  <Image src={imageUrl} alt="Preview" width={400} height={400} className="w-full h-auto max-h-64 object-contain rounded" />
                </div>
              )}
            </TabsContent>
            <TabsContent value="text" className="mt-6">
              <div className="space-y-2">
                <Label htmlFor="waste-description">Description</Label>
                <Textarea
                  id="waste-description"
                  placeholder="e.g., A plastic bottle with a blue cap, a cracked phone screen, a used pizza box with grease stains..."
                  value={description}
                  onChange={(e) => {setDescription(e.target.value); setResult(null); setError(null);}}
                  className="min-h-[120px]"
                  disabled={isLoading}
                />
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end gap-2 mt-6">
            {(imageUrl || description) && !isLoading && (
              <Button variant="outline" onClick={handleReset}>Clear</Button>
            )}
            <Button onClick={handleSubmit} disabled={isLoading || (inputMode === 'image' && !imageUrl) || (inputMode === 'text' && !description)}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
              Identify Item
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {isLoading && (
        <Card className="mt-8">
            <CardHeader>
                <div className="flex items-center gap-4">
                <Sparkles className="h-6 w-6 text-primary animate-pulse" />
                <CardTitle className="font-headline">Analyzing...</CardTitle>
                </div>
            </CardHeader>
            <CardContent className="flex flex-col sm:flex-row items-center justify-center py-16 gap-4 text-center">
                <Loader2 className="h-12 w-12 text-primary animate-spin" />
                <p className="text-muted-foreground">Our AI is hard at work identifying your item.<br/>This might take a few moments.</p>
            </CardContent>
        </Card>
      )}

      {error && !isLoading && (
        <Card className="mt-8 border-destructive">
          <CardHeader>
              <div className="flex items-center gap-4">
                <FileWarning className="h-6 w-6 text-destructive" />
                <CardTitle className="font-headline text-destructive">Identification Failed</CardTitle>
              </div>
            </CardHeader>
          <CardContent>
            <p className="text-destructive">{error}</p>
          </CardContent>
        </Card>
      )}

      {result && !isLoading && <IdentificationResult result={result} />}

    </div>
  );
}
