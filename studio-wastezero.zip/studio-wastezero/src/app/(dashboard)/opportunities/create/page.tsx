import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PlusCircle } from "lucide-react";
import type { WasteType } from "@/lib/types";

const wasteTypes: WasteType[] = ['plastic', 'organic', 'e-waste', 'metal', 'paper', 'glass', 'textile'];

export default function CreateOpportunityPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">Create a New Opportunity</h1>
        <p className="text-muted-foreground">Fill in the details below to post a new volunteering opportunity.</p>
      </div>

      <Card>
        <CardHeader>
            <CardTitle>Opportunity Details</CardTitle>
            <CardDescription>Provide as much information as possible to attract the right volunteers.</CardDescription>
        </CardHeader>
        <CardContent>
            <form className="space-y-6">
                 <div className="space-y-2">
                    <Label htmlFor="title">Opportunity Title</Label>
                    <Input id="title" placeholder="e.g., Downtown River Cleanup" />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" placeholder="Describe the opportunity, its goals, and what volunteers will be doing." className="min-h-[120px]" />
                </div>
                 <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="location">Location</Label>
                        <Input id="location" placeholder="e.g., Central Park, New York" />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="duration">Estimated Duration</Label>
                        <Input id="duration" placeholder="e.g., 3 hours" />
                    </div>
                </div>
                 <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="waste-type">Primary Waste Type</Label>
                        <Select>
                            <SelectTrigger id="waste-type">
                                <SelectValue placeholder="Select a waste type" />
                            </SelectTrigger>
                            <SelectContent>
                                {wasteTypes.map(type => (
                                    <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="skills">Required Skills (comma-separated)</Label>
                        <Input id="skills" placeholder="e.g., Heavy Lifting, Sorting" />
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="image">Featured Image</Label>
                    <Input id="image" type="file" />
                    <p className="text-xs text-muted-foreground">Upload an image that represents the opportunity.</p>
                </div>
                <div className="flex justify-end">
                    <Button type="submit">
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Publish Opportunity
                    </Button>
                </div>
            </form>
        </CardContent>
      </Card>
    </div>
  );
}
