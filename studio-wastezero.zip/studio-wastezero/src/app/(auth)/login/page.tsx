"use client";

import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/hooks/use-toast';
import type { UserRole } from '@/lib/types';
import { Loader2, KeyRound, AtSign } from 'lucide-react';

export default function LoginPage() {
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  
  // State for password form
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('volunteer');

  // State for OTP form
  const [otpEmail, setOtpEmail] = useState('');
  const [otp, setOtp] = useState('');

  const handlePasswordLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        title: 'Missing Fields',
        description: 'Please enter both email and password.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);
    // Simulate API call for login
    setTimeout(() => {
      login(email, role);
      setIsLoading(false);
      toast({
        title: 'Login Successful',
        description: "Welcome back!",
      });
    }, 1000);
  };
  
  const handleSendOtp = () => {
    if (!otpEmail) {
       toast({
        title: 'Email Required',
        description: 'Please enter your email address to receive an OTP.',
        variant: 'destructive',
      });
      return;
    }
    setIsSendingOtp(true);
    setTimeout(() => {
        setIsSendingOtp(false);
        setOtpSent(true);
        toast({
            title: 'OTP Sent',
            description: `A one-time password has been sent to ${otpEmail}. (This is a simulation)`,
        });
        toast({
            title: 'Your Simulated OTP',
            description: 'Your OTP is: 123456',
        });
    }, 1500)
  }

  const handleOtpLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
     if (otp !== '123456') {
      toast({
        title: 'Invalid OTP',
        description: 'The OTP you entered is incorrect. Please try again.',
        variant: 'destructive',
      });
      return;
    }
    setIsLoading(true);
     // Simulate API call for login
    setTimeout(() => {
      login(otpEmail, role);
      setIsLoading(false);
      toast({
        title: 'Login Successful',
        description: "Welcome back!",
      });
    }, 1000);
  }

  return (
    <Card className="w-full max-w-md shadow-xl">
        <Tabs defaultValue="password" className="w-full">
            <CardHeader className='pb-2'>
                <CardTitle className="text-2xl font-headline text-center">Welcome Back</CardTitle>
                <CardDescription className='text-center'>Choose your login method.</CardDescription>
                <TabsList className="grid w-full grid-cols-2 mt-4">
                    <TabsTrigger value="password"><KeyRound className="mr-2 h-4 w-4"/> Password</TabsTrigger>
                    <TabsTrigger value="otp"><AtSign className="mr-2 h-4 w-4"/> Email OTP</TabsTrigger>
                </TabsList>
            </CardHeader>

            <TabsContent value="password">
                <form onSubmit={handlePasswordLoginSubmit}>
                    <CardContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" placeholder="name@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="password">Password</Label>
                        <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label>Role</Label>
                        <RadioGroup defaultValue="volunteer" value={role} onValueChange={(value: UserRole) => setRole(value)} className="flex gap-4">
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="volunteer" id="r1" />
                            <Label htmlFor="r1">Volunteer</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="ngo" id="r2" />
                            <Label htmlFor="r2">NGO</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                            <RadioGroupItem value="admin" id="r3" />
                            <Label htmlFor="r3">Admin</Label>
                        </div>
                        </RadioGroup>
                    </div>
                    </CardContent>
                    <CardFooter className="flex-col gap-4">
                    <Button className="w-full" type="submit" disabled={isLoading}>
                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Login
                    </Button>
                    </CardFooter>
                </form>
            </TabsContent>

            <TabsContent value="otp">
                <form onSubmit={handleOtpLoginSubmit}>
                    <CardContent className="space-y-4 pt-4">
                         <div className="space-y-2">
                            <Label htmlFor="otp-email">Email</Label>
                            <div className='flex gap-2'>
                                <Input id="otp-email" type="email" placeholder="name@example.com" value={otpEmail} onChange={(e) => setOtpEmail(e.target.value)} required disabled={otpSent}/>
                                <Button type="button" onClick={handleSendOtp} disabled={isSendingOtp || otpSent} className="w-40">
                                    {isSendingOtp ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : (otpSent ? 'OTP Sent' : 'Send OTP')}
                                </Button>
                            </div>
                        </div>
                        {otpSent && (
                            <div className="space-y-2 animate-in fade-in-50">
                                <Label htmlFor="otp">One-Time Password</Label>
                                <Input id="otp" type="text" placeholder="Enter your 6-digit OTP" value={otp} onChange={(e) => setOtp(e.target.value)} required maxLength={6}/>
                            </div>
                        )}
                        <div className="space-y-2">
                            <Label>Role</Label>
                            <RadioGroup defaultValue="volunteer" value={role} onValueChange={(value: UserRole) => setRole(value)} className="flex gap-4">
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="volunteer" id="r1-otp" />
                                <Label htmlFor="r1-otp">Volunteer</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="ngo" id="r2-otp" />
                                <Label htmlFor="r2-otp">NGO</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="admin" id="r3-otp" />
                                <Label htmlFor="r3-otp">Admin</Label>
                            </div>
                            </RadioGroup>
                        </div>
                    </CardContent>
                    <CardFooter className="flex-col gap-4">
                        <Button className="w-full" type="submit" disabled={isLoading || !otpSent || otp.length < 6}>
                            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Login with OTP
                        </Button>
                    </CardFooter>
                </form>
            </TabsContent>
            <div className='p-6 pt-0 text-center text-xs text-muted-foreground'>
                <p>
                    Don&apos;t have an account?{' '}
                    <Link href="/register" className="font-medium text-primary hover:underline">
                    Sign up
                    </Link>
                </p>
            </div>
        </Tabs>
    </Card>
  );
}
