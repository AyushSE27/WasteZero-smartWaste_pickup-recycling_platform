"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { users as initialUsers, opportunities, pickups } from "@/lib/data";
import { Users, Recycle, HandHeart, Truck, UserPlus, FileText, CheckSquare, XSquare } from "lucide-react";
import { UserGrowthChart } from "@/components/charts/user-growth-chart";
import { WasteDistributionChart } from "@/components/charts/waste-distribution-chart";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "../ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import type { User, Opportunity, Pickup } from "@/lib/types";

const adminLogs = [
    { id: '1', user: 'Admin', action: 'Suspended user "volunteer7"', timestamp: new Date() },
    { id: '2', user: 'Admin', action: 'Deleted opportunity "Obsolete Cleanup"', timestamp: new Date(Date.now() - 3600000) },
    { id: '3', user: 'Admin', action: 'Approved NGO "Eco Warriors"', timestamp: new Date(Date.now() - 7200000) },
    { id: '4', user: 'Admin', action: 'Flagged content in messages', timestamp: new Date(Date.now() - 86400000) },
]

export function AdminDashboard() {
    const [platformUsers, setPlatformUsers] = useState<User[]>(initialUsers);
    const { toast } = useToast();

    const stats = {
        totalUsers: platformUsers.length,
        totalVolunteers: platformUsers.filter(u => u.role === 'volunteer').length,
        totalNgos: platformUsers.filter(u => u.role === 'ngo').length,
        totalOpportunities: opportunities.length,
        activePickups: pickups.filter(p => p.status === 'scheduled').length,
    }
  
    const recentUsers = platformUsers.slice(0, 5);

    const handleDeleteUser = (userId: string) => {
        setPlatformUsers(currentUsers => currentUsers.filter(user => user.id !== userId));
        toast({
            title: "User Deleted",
            description: "The user has been successfully removed.",
            variant: "destructive"
        });
    };

    const handleDownloadReports = () => {
        // Helper function to download CSV
        const downloadCsv = (csvContent: string, fileName: string) => {
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", fileName);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        };

        const sanitize = (value: any): string => {
            const str = String(value);
            if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                return `"${str.replace(/"/g, '""')}"`;
            }
            return str;
        };

        // 1. Users Report
        const userHeaders: (keyof User)[] = ['id', 'name', 'email', 'role', 'location', 'skills', 'isSuspended', 'createdAt'];
        const userRows = platformUsers.map(user => 
            userHeaders.map(header => {
                const value = user[header];
                if(Array.isArray(value)) return sanitize(value.join('|'));
                return sanitize(value);
            }).join(',')
        );
        const userCsv = [userHeaders.join(','), ...userRows].join('\n');
        downloadCsv(userCsv, 'users-report.csv');

        // 2. Opportunities Report
        const oppHeaders: (keyof Opportunity)[] = ['id', 'ngoName', 'title', 'wasteType', 'status', 'location', 'duration', 'createdAt'];
        const oppRows = opportunities.map(opp => 
            oppHeaders.map(header => {
                const value = opp[header];
                if(Array.isArray(value)) return sanitize(value.join('|'));
                return sanitize(value);
            }).join(',')
        );
        const oppCsv = [oppHeaders.join(','), ...oppRows].join('\n');
        downloadCsv(oppCsv, 'opportunities-report.csv');
        
        // 3. Pickups Report
        const pickupHeaders: (keyof Pickup)[] = ['id', 'userId', 'wasteType', 'date', 'address', 'status'];
        const pickupRows = pickups.map(p => 
            pickupHeaders.map(header => sanitize(p[header])).join(',')
        );
        const pickupCsv = [pickupHeaders.join(','), ...pickupRows].join('\n');
        downloadCsv(pickupCsv, 'pickups-report.csv');
    
        toast({
            title: "Reports Downloading",
            description: "Users, opportunities, and pickups reports are being downloaded.",
        });
    };

  return (
    <div className="space-y-6">
        <div>
            <h1 className="text-3xl font-bold font-headline">Admin Dashboard</h1>
            <p className="text-muted-foreground">Oversee platform activity and manage users.</p>
        </div>
        <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
            <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-4xl font-bold">{stats.totalUsers}</div>
                    <p className="text-xs text-muted-foreground">All registered users</p>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Volunteers</CardTitle>
                    <HandHeart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-4xl font-bold">{stats.totalVolunteers}</div>
                     <p className="text-xs text-muted-foreground">Active volunteers</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">NGOs</CardTitle>
                    <Recycle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-4xl font-bold">{stats.totalNgos}</div>
                     <p className="text-xs text-muted-foreground">Verified organizations</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Opportunities</CardTitle>
                    <CheckSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-4xl font-bold">{stats.totalOpportunities}</div>
                     <p className="text-xs text-muted-foreground">Total posts</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium">Active Pickups</CardTitle>
                    <Truck className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-4xl font-bold">{stats.activePickups}</div>
                     <p className="text-xs text-muted-foreground">Scheduled collections</p>
                </CardContent>
            </Card>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-7 gap-6">
            <Card className="lg:col-span-4">
                <CardHeader>
                    <CardTitle>User Growth</CardTitle>
                    <CardDescription>Total users on the platform over the last 6 months.</CardDescription>
                </CardHeader>
                <CardContent>
                    <UserGrowthChart />
                </CardContent>
            </Card>
            <Card className="lg:col-span-3">
                <CardHeader>
                    <CardTitle>Waste Distribution</CardTitle>
                    <CardDescription>Distribution of waste types from all scheduled pickups.</CardDescription>
                </CardHeader>
                <CardContent>
                    <WasteDistributionChart />
                </CardContent>
            </Card>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
                <CardHeader>
                    <CardTitle>Recent Users</CardTitle>
                    <CardDescription>The latest users to join the platform.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>User</TableHead>
                                <TableHead>Role</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {recentUsers.map(user => (
                            <TableRow key={user.id}>
                                <TableCell className="font-medium">{user.name}</TableCell>
                                <TableCell><Badge variant="outline" className="capitalize">{user.role}</Badge></TableCell>
                                <TableCell className="text-right">
                                    <Button variant="ghost" size="icon"><UserPlus className="h-4 w-4" /></Button>
                                    <AlertDialog>
                                        <AlertDialogTrigger asChild>
                                            <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                                                <XSquare className="h-4 w-4" />
                                            </Button>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent>
                                            <AlertDialogHeader>
                                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                            <AlertDialogDescription>
                                                This action cannot be undone. This will permanently delete the user from the platform.
                                            </AlertDialogDescription>
                                            </AlertDialogHeader>
                                            <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction 
                                                onClick={() => handleDeleteUser(user.id)}
                                            >
                                                Delete
                                            </AlertDialogAction>
                                            </AlertDialogFooter>
                                        </AlertDialogContent>
                                    </AlertDialog>
                                </TableCell>
                            </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle>Admin Actions Log</CardTitle>
                        <CardDescription>Recent administrative activity.</CardDescription>
                    </div>
                     <Button variant="outline" size="sm" onClick={handleDownloadReports}><FileText className="mr-2 h-4 w-4"/> Download Reports</Button>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Action</TableHead>
                                <TableHead>Timestamp</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {adminLogs.map(log => (
                            <TableRow key={log.id}>
                                <TableCell className="font-medium">{log.action}</TableCell>
                                <TableCell>{log.timestamp.toLocaleDateString()}</TableCell>
                            </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    </div>
  );
}
