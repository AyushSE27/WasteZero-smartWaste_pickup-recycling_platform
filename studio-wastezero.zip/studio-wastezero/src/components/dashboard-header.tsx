"use client";

import { SidebarTrigger } from "@/components/ui/sidebar";
import { UserNav } from "@/components/user-nav";
import { useAuth } from "@/hooks/use-auth";
import { Skeleton } from "@/components/ui/skeleton";
import { ThemeToggle } from "./theme-toggle";

export function DashboardHeader() {
  const { user, loading } = useAuth();
  
  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
       <div className="md:hidden">
         <SidebarTrigger />
       </div>
       <div className="flex-1">
        {loading ? (
            <Skeleton className="h-6 w-48" />
        ) : (
            <h1 className="text-lg font-semibold md:text-xl font-headline">
                Welcome, {user?.name.split(' ')[0]}
            </h1>
        )}
       </div>
      <div className="flex items-center gap-2">
        <ThemeToggle />
        <UserNav />
      </div>
    </header>
  );
}
