"use client";

import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Opportunity } from "@/lib/types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MapPin, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function OpportunityCard({ opportunity }: { opportunity: Opportunity }) {
  const { title, ngoName, ngoLogoUrl, location, duration, requiredSkills, imageUrl, wasteType } = opportunity;
  const { toast } = useToast();
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .substring(0, 2).toUpperCase();
  };

  const handleApply = () => {
    toast({
      title: "Application Sent!",
      description: `You have successfully applied for "${title}".`,
    });
  };

  return (
    <Card className="flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <Image
          src={imageUrl}
          alt={title}
          width={400}
          height={200}
          className="w-full h-40 object-cover"
        />
        <Badge className="absolute top-2 right-2 capitalize" variant="secondary">{wasteType}</Badge>
      </div>
      <CardHeader>
        <div className="flex items-center gap-3 mb-2">
          <Avatar className="h-10 w-10">
            <AvatarImage src={ngoLogoUrl} alt={ngoName} />
            <AvatarFallback>{getInitials(ngoName)}</AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-semibold text-primary">{ngoName}</p>
            <CardTitle className="text-lg font-headline leading-tight">{title}</CardTitle>
          </div>
        </div>
         <div className="flex items-center text-xs text-muted-foreground gap-4">
            <div className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                <span>{location}</span>
            </div>
             <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{duration}</span>
            </div>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <div className="flex flex-wrap gap-2">
          {requiredSkills.map(skill => (
            <Badge key={skill} variant="outline">{skill}</Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <Button className="w-full" onClick={handleApply}>Apply Now</Button>
      </CardFooter>
    </Card>
  );
}
