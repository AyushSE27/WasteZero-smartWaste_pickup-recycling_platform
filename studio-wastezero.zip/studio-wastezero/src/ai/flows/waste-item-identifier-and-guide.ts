'use server';
/**
 * @fileOverview An AI agent for identifying waste items and providing recycling/disposal instructions.
 *
 * - wasteItemIdentifierAndGuide - A function that handles the waste identification and instruction process.
 * - WasteItemIdentifierAndGuideInput - The input type for the wasteItemIdentifierAndGuide function.
 * - WasteItemIdentifierAndGuideOutput - The return type for the wasteItemIdentifierAndGuide function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const WasteItemIdentifierAndGuideInputSchema = z
  .object({
    wasteImage: z
      .string()
      .optional()
      .describe(
        "An optional photo of a waste item, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
      ),
    wasteDescription: z
      .string()
      .optional()
      .describe('An optional text description of the waste item.'),
  })
  .refine(data => data.wasteImage || data.wasteDescription, {
    message: 'Either wasteImage or wasteDescription must be provided.',
    path: ['wasteImage', 'wasteDescription'],
  });
export type WasteItemIdentifierAndGuideInput = z.infer<
  typeof WasteItemIdentifierAndGuideInputSchema
>;

const WasteItemIdentifierAndGuideOutputSchema = z.object({
  wasteType: z
    .enum(['plastic', 'organic', 'e-waste', 'metal', 'paper', 'glass', 'textile', 'unknown', 'hazardous'])
    .describe(
      "The identified type of waste (e.g., 'plastic', 'organic', 'e-waste', 'metal', 'paper', 'glass', 'textile', 'unknown', 'hazardous')."
    ),
  identificationConfidence: z
    .number()
    .min(0)
    .max(100)
    .describe(
      'A confidence score (0-100) indicating how sure the AI is about the identification.'
    ),
  disposalInstructions: z
    .string()
    .describe(
      'Clear, actionable instructions for proper recycling or disposal of the identified waste item.'
    ),
  isRecyclable: z.boolean().describe('True if the item is recyclable, false otherwise.'),
});
export type WasteItemIdentifierAndGuideOutput = z.infer<
  typeof WasteItemIdentifierAndGuideOutputSchema
>;

const wasteItemIdentifierAndGuidePrompt = ai.definePrompt({
  name: 'wasteItemIdentifierAndGuidePrompt',
  input: {schema: WasteItemIdentifierAndGuideInputSchema},
  output: {schema: WasteItemIdentifierAndGuideOutputSchema},
  model: 'googleai/gemini-pro-vision',
  prompt: `You are an expert in waste management and recycling. Your task is to identify waste items and provide precise disposal instructions.

Analyze the provided image and/or description of a waste item. Based on your analysis, determine the waste type, assign a confidence score, and provide clear recycling or disposal instructions.

Input:
{{#if wasteImage}}Image: {{media url=wasteImage}}{{/if}}
{{#if wasteDescription}}Description: {{{wasteDescription}}}{{/if}}

`,
});

const wasteItemIdentifierAndGuideFlow = ai.defineFlow(
  {
    name: 'wasteItemIdentifierAndGuideFlow',
    inputSchema: WasteItemIdentifierAndGuideInputSchema,
    outputSchema: WasteItemIdentifierAndGuideOutputSchema,
  },
  async input => {
    // The prompt is defined to accept the WasteItemIdentifierAndGuideInput directly,
    // and uses Handlebars conditionals to include image or text parts.
    // Therefore, the prompt can be called directly with the input object.
    const {output} = await wasteItemIdentifierAndGuidePrompt(input);
    return output!;
  }
);

export async function wasteItemIdentifierAndGuide(
  input: WasteItemIdentifierAndGuideInput
):
Promise<WasteItemIdentifierAndGuideOutput> {
  return wasteItemIdentifierAndGuideFlow(input);
}
