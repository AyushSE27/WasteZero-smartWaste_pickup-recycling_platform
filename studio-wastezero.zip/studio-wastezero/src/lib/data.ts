import { User, Opportunity, Application, Pickup, Message, UserRole, OpportunityStatus, ApplicationStatus, PickupStatus, WasteType } from './types';

const USER_ROLES: UserRole[] = ['volunteer', 'ngo', 'admin'];
const WASTE_TYPES: WasteType[] = ['plastic', 'organic', 'e-waste', 'metal', 'paper', 'glass', 'textile'];
const SKILLS = ['Sorting', 'Heavy Lifting', 'Driving', 'Community Outreach', 'Data Entry', 'First Aid', 'Logistics'];
const LOCATIONS = ['Mumbai, India', 'Delhi, India', 'Bengaluru, India', 'Chennai, India', 'Kolkata, India'];
const NGO_NAMES = ['Green Earth Foundation', 'Clean Oceans Initiative', 'Eco Warriors', 'Recycle Forward', 'Urban Gardeners'];

const getRandomElement = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const getRandomSubset = <T>(arr: T[], max = 3): T[] => {
  const shuffled = arr.sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.floor(Math.random() * max) + 1);
};

const shuffledNgoNames = NGO_NAMES.sort(() => 0.5 - Math.random());
let ngoNameIndex = 0;

export const users: User[] = Array.from({ length: 20 }, (_, i) => {
  const role = i === 0 ? 'admin' : i < 5 ? 'ngo' : 'volunteer';
  const name = role === 'ngo' ? shuffledNgoNames[ngoNameIndex++] : `User ${i + 1}`;
  return ({
  id: `user-${i + 1}`,
  name,
  email: `${role}${i + 1}@wastezero.com`,
  role,
  skills: role === 'volunteer' ? getRandomSubset(SKILLS) : [],
  location: getRandomElement(LOCATIONS),
  bio: `This is a bio for ${name}. I am passionate about making the world a cleaner place.`,
  isSuspended: false,
  avatarUrl: `https://picsum.photos/seed/avatar${i+1}/100/100`,
  createdAt: new Date(Date.now() - Math.random() * 1000 * 3600 * 24 * 30).toISOString(),
})});

export const opportunities: Opportunity[] = Array.from({ length: 15 }, (_, i) => {
  const ngo = getRandomElement(users.filter(u => u.role === 'ngo'));
  return {
    id: `opp-${i + 1}`,
    ngoId: ngo.id,
    ngoName: ngo.name,
    ngoLogoUrl: ngo.avatarUrl,
    title: `Community Cleanup #${i + 1}`,
    description: `Join us for a community cleanup event. We'll be focusing on ${getRandomElement(WASTE_TYPES)} waste in the downtown area. A great way to meet new people and make a tangible impact.`,
    requiredSkills: getRandomSubset(SKILLS, 2),
    wasteType: getRandomElement(WASTE_TYPES),
    duration: `${Math.floor(Math.random() * 4) + 2} hours`,
    location: ngo.location,
    status: getRandomElement(['open', 'open', 'in-progress', 'closed']) as OpportunityStatus,
    createdAt: new Date(Date.now() - Math.random() * 1000 * 3600 * 24 * 30).toISOString(),
    imageUrl: `https://picsum.photos/seed/opp${i+1}/400/250`,
  };
});

export const applications: Application[] = Array.from({ length: 30 }, (_, i) => {
  const volunteer = getRandomElement(users.filter(u => u.role === 'volunteer'));
  const opportunity = getRandomElement(opportunities.filter(o => o.status === 'open'));
  return {
    id: `app-${i + 1}`,
    opportunityId: opportunity.id,
    volunteerId: volunteer.id,
    status: getRandomElement(['pending', 'accepted', 'rejected']) as ApplicationStatus,
    createdAt: new Date(Date.now() - Math.random() * 1000 * 3600 * 24 * 10).toISOString(),
  };
});

export const pickups: Pickup[] = Array.from({ length: 25 }, (_, i) => ({
  id: `pickup-${i + 1}`,
  userId: getRandomElement(users).id,
  wasteType: getRandomElement(WASTE_TYPES),
  date: new Date(Date.now() + Math.random() * 1000 * 3600 * 24 * 14).toISOString(),
  address: `${Math.floor(Math.random() * 900) + 100} Main St, ${getRandomElement(LOCATIONS)}`,
  status: getRandomElement(['scheduled', 'completed', 'cancelled']) as PickupStatus,
}));

export const messages: Message[] = [
  {
    id: 'msg-1',
    senderId: 'user-6',
    receiverId: 'user-2',
    content: 'Hi! I am interested in the beach cleanup. Can you tell me more about it?',
    timestamp: new Date(Date.now() - 1000 * 3600 * 2).toISOString(),
  },
  {
    id: 'msg-2',
    senderId: 'user-2',
    receiverId: 'user-6',
    content: "Of course! We'll be meeting at 9 AM at the main entrance. We provide all the gear. Just bring yourself and a positive attitude!",
    timestamp: new Date(Date.now() - 1000 * 3600 * 1.9).toISOString(),
  },
  {
    id: 'msg-3',
    senderId: 'user-6',
    receiverId: 'user-2',
    content: 'Sounds great, I just applied!',
    timestamp: new Date(Date.now() - 1000 * 3600 * 1.8).toISOString(),
  }
];
