if (!localStorage.getItem("token")) {
  window.location.href = "login.html";
}

document.querySelector(".logout")?.addEventListener("click", () => {
  localStorage.removeItem("token");
  window.location.href = "login.html";
});
