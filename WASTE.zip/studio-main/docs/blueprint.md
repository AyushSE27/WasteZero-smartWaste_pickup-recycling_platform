# **App Name**: WasteWise

## Core Features:

- User Authentication: Secure registration and login with JWT and OTP verification. Supports Volunteer, NGO, and Admin roles.
- Opportunity Creation & Management: NGOs can create, edit, and delete opportunities with details like skills, waste type, and location.
- Volunteer Application: Volunteers can view opportunities and submit applications.
- Intelligent Matching Tool: An algorithm matches volunteers to opportunities based on skills, location, and opportunity status.
- Real-time Chat: Socket.io-powered real-time messaging between users for efficient communication.
- Waste Pickup Scheduling: Users can schedule waste pickups, specifying waste type, date, and address.
- Admin Dashboard: Comprehensive admin panel with user statistics, waste tracking charts, and controls to manage users and opportunities.

## Style Guidelines:

- Primary color: Forest green (#4CAF50) to evoke sustainability and nature.
- Background color: Light gray (#F5F5F5) for a clean, modern look.
- Accent color: Light orange (#FFB74D) for CTAs and highlights.
- Body font: 'PT Sans', a modern, humanist sans-serif suitable for body text. Headline font: 'Space Grotesk' to maintain a tech-friendly feeling for headlines.
- Use eco-friendly icons representing waste types, user roles, and actions.
- Responsive, grid-based layout with sidebar navigation for easy access to features.
- Subtle transitions and animations to enhance user experience.