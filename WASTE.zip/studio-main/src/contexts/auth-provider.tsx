"use client"

import React, { createContext, useState, useEffect, useCallback } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import type { User, UserRole } from '@/lib/types';
import { users } from '@/lib/data';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, role: UserRole) => void;
  logout: () => void;
  loading: boolean;
}

export const AuthContext = createContext<AuthContextType | null>(null);

const AUTH_STORAGE_KEY = 'wastezero_user';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem(AUTH_STORAGE_KEY);
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error('Failed to parse user from localStorage', error);
      localStorage.removeItem(AUTH_STORAGE_KEY);
    }
    setLoading(false);
  }, []);

  const login = useCallback((email: string, role: UserRole) => {
    // In a real app, you'd fetch this from your backend
    const foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.role === role);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(foundUser));
      router.push('/dashboard');
    } else {
        const mockUser = users.find(u => u.role === role);
        if(mockUser){
            setUser(mockUser);
            localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(mockUser));
            router.push('/dashboard');
        } else {
            // Fallback for safety
             const adminUser = users.find(u => u.role === 'admin')!;
             setUser(adminUser);
             localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(adminUser));
             router.push('/dashboard');
        }
    }
  }, [router]);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem(AUTH_STORAGE_KEY);
    router.push('/login');
  }, [router]);
  
  // Route protection
  useEffect(() => {
    if (loading) return;

    const isAuthPage = pathname === '/login' || pathname === '/register';
    
    if (!user && !isAuthPage && pathname !== '/') {
        router.push('/login');
    }

    if (user && isAuthPage) {
        router.push('/dashboard');
    }

  }, [user, loading, pathname, router]);


  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}
