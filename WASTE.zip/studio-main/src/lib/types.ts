export type UserRole = 'volunteer' | 'ngo' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  skills: string[];
  location: string;
  bio: string;
  isSuspended: boolean;
  avatarUrl: string;
  createdAt: string;
}

export type OpportunityStatus = 'open' | 'closed' | 'in-progress';
export type WasteType = 'plastic' | 'organic' | 'e-waste' | 'metal' | 'paper' | 'glass' | 'textile';

export interface Opportunity {
  id: string;
  ngoId: string;
  ngoName: string;
  ngoLogoUrl: string;
  title: string;
  description: string;
  requiredSkills: string[];
  wasteType: WasteType;
  duration: string;
  location: string;
  status: OpportunityStatus;
  createdAt: string;
  imageUrl: string;
}

export type ApplicationStatus = 'pending' | 'accepted' | 'rejected';

export interface Application {
  id: string;
  opportunityId: string;
  volunteerId: string;
  status: ApplicationStatus;
  createdAt: string;
}

export type PickupStatus = 'scheduled' | 'completed' | 'cancelled';

export interface Pickup {
  id: string;
  userId: string;
  wasteType: WasteType;
  date: string;
  address: string;
  status: PickupStatus;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
}

export interface AdminLog {
  id: string;
  action: string;
  userId: string;
  timestamp: string;
}
