import { config } from 'dotenv';
config();

import '@/ai/flows/ngo-opportunity-description-assistant.ts';
import '@/ai/flows/volunteer-profile-enhancer.ts';
import '@/ai/flows/waste-item-identifier-and-guide.ts';