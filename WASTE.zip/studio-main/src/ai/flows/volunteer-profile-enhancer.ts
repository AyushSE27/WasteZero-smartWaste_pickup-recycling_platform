'use server';
/**
 * @fileOverview A Genkit flow for enhancing a volunteer's profile by suggesting relevant skills and refining their bio.
 *
 * - enhanceVolunteerProfile - A function that handles the profile enhancement process.
 * - VolunteerProfileEnhancerInput - The input type for the enhanceVolunteerProfile function.
 * - VolunteerProfileEnhancerOutput - The return type for the enhanceVolunteerProfile function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const VolunteerProfileEnhancerInputSchema = z.object({
  currentSkills: z
    .array(z.string())
    .describe('A list of skills the volunteer currently possesses.'),
  currentBio: z
    .string()
    .describe("The volunteer's current biographical description."),
  interests: z
    .array(z.string())
    .describe('A list of areas or activities the volunteer is interested in.'),
});
export type VolunteerProfileEnhancerInput = z.infer<
  typeof VolunteerProfileEnhancerInputSchema
>;

const VolunteerProfileEnhancerOutputSchema = z.object({
  suggestedSkills: z
    .array(z.string())
    .describe('A list of additional relevant skills suggested for the volunteer.'),
  refinedBio: z
    .string()
    .describe("A refined and improved version of the volunteer's bio."),
});
export type VolunteerProfileEnhancerOutput = z.infer<
  typeof VolunteerProfileEnhancerOutputSchema
>;

export async function enhanceVolunteerProfile(
  input: VolunteerProfileEnhancerInput
): Promise<VolunteerProfileEnhancerOutput> {
  return volunteerProfileEnhancerFlow(input);
}

const prompt = ai.definePrompt({
  name: 'volunteerProfileEnhancerPrompt',
  input: {schema: VolunteerProfileEnhancerInputSchema},
  output: {schema: VolunteerProfileEnhancerOutputSchema},
  prompt: `You are an AI assistant designed to help volunteers enhance their profiles for a waste pickup and recycling platform.
Your goal is to suggest additional relevant skills and refine the volunteer's bio based on their current inputs and interests.

Instructions:
1. Review the provided current skills, current bio, and interests.
2. Based on this information, suggest up to 5 additional relevant skills that a volunteer might possess or find useful for waste management and recycling opportunities. These skills should be practical and actionable (e.g., 'Heavy Lifting', 'First Aid', 'Data Entry', 'Community Outreach', 'Logistics Planning'). Ensure they are distinct from the current skills.
3. Refine the provided current bio to make it more professional, engaging, and suitable for a volunteer profile on a sustainability platform. Highlight relevant experience, passion for environmental causes, and any skills that align with waste management or community service. Keep it concise, around 100-200 words.

Current Skills: {{{currentSkills}}}
Current Bio: {{{currentBio}}}
Interests: {{{interests}}}`,
});

const volunteerProfileEnhancerFlow = ai.defineFlow(
  {
    name: 'volunteerProfileEnhancerFlow',
    inputSchema: VolunteerProfileEnhancerInputSchema,
    outputSchema: VolunteerProfileEnhancerOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
