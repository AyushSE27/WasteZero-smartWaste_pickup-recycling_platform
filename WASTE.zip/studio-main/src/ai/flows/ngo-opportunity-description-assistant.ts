'use server';
/**
 * @fileOverview An AI assistant that helps NGOs generate comprehensive and engaging descriptions for volunteering opportunities.
 *
 * - ngoOpportunityDescriptionAssistant - A function that handles the generation of the opportunity description.
 * - NgoOpportunityDescriptionAssistantInput - The input type for the ngoOpportunityDescriptionAssistant function.
 * - NgoOpportunityDescriptionAssistantOutput - The return type for the ngoOpportunityDescriptionAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const NgoOpportunityDescriptionAssistantInputSchema = z.object({
  wasteType: z.string().describe('The type of waste involved in the opportunity (e.g., plastic, organic, e-waste).'),
  location: z.string().describe('The geographical location where the volunteering opportunity will take place.'),
  requiredSkills: z.array(z.string()).describe('A list of skills required or preferred for volunteers (e.g., heavy lifting, communication, sorting).'),
});
export type NgoOpportunityDescriptionAssistantInput = z.infer<typeof NgoOpportunityDescriptionAssistantInputSchema>;

const NgoOpportunityDescriptionAssistantOutputSchema = z.object({
  description: z.string().describe('A comprehensive and engaging description for the volunteering opportunity.'),
});
export type NgoOpportunityDescriptionAssistantOutput = z.infer<typeof NgoOpportunityDescriptionAssistantOutputSchema>;

export async function ngoOpportunityDescriptionAssistant(input: NgoOpportunityDescriptionAssistantInput): Promise<NgoOpportunityDescriptionAssistantOutput> {
  return ngoOpportunityDescriptionAssistantFlow(input);
}

const ngoOpportunityDescriptionPrompt = ai.definePrompt({
  name: 'ngoOpportunityDescriptionPrompt',
  input: {schema: NgoOpportunityDescriptionAssistantInputSchema},
  output: {schema: NgoOpportunityDescriptionAssistantOutputSchema},
  prompt: `You are a skilled copywriter specializing in creating compelling descriptions for NGO volunteering opportunities. Your goal is to write an engaging and comprehensive description that clearly outlines the opportunity, its impact, and what is expected of volunteers.

Based on the following brief inputs, generate a detailed and inspiring volunteering opportunity description:

Waste Type: {{{wasteType}}}
Location: {{{location}}}
Required Skills: {{#each requiredSkills}}- {{{this}}}
{{/each}}

Make sure the description highlights the positive impact volunteers will have and encourages suitable candidates to apply. The description should be professional, welcoming, and clearly convey the purpose and benefits of participating.`,
});

const ngoOpportunityDescriptionAssistantFlow = ai.defineFlow(
  {
    name: 'ngoOpportunityDescriptionAssistantFlow',
    inputSchema: NgoOpportunityDescriptionAssistantInputSchema,
    outputSchema: NgoOpportunityDescriptionAssistantOutputSchema,
  },
  async input => {
    const {output} = await ngoOpportunityDescriptionPrompt(input);
    return output!;
  }
);
