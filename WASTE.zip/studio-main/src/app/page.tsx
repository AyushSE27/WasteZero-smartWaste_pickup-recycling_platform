
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Recycle,
  Users,
  Handshake,
  Truck,
  MessageCircle,
  LineChart,
  ChevronRight,
} from 'lucide-react';
import { Logo } from '@/components/logo';
import placeholderData from '@/lib/placeholder-images.json';

const PlaceHolderImages = placeholderData.placeholderImages;

const featuresData = [
  {
    icon: Recycle,
    title: 'Smart Recycling',
    description: 'Easily schedule pickups for various waste types and track their journey.',
    imageId: "feature-1",
  },
  {
    icon: Users,
    title: 'Community Building',
    description: 'Connect with NGOs and volunteers passionate about creating a cleaner environment.',
    imageId: "feature-2",
  },
  {
    icon: Handshake,
    title: 'Opportunity Matching',
    description: 'Our intelligent algorithm connects volunteers with the right opportunities.',
    imageId: "feature-3",
  },
];

export default function Home() {
  const [year, setYear] = useState<number | null>(null);

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  const heroImage = PlaceHolderImages?.find(img => img.id === "hero");
  const features = featuresData.map(feature => ({
      ...feature,
      image: PlaceHolderImages?.find(img => img.id === feature.imageId)
  }));

  return (
    <div className="flex flex-col min-h-screen">
      <header className="container mx-auto flex items-center justify-between p-4">
        <Logo />
        <div className="flex items-center gap-4">
          <Button variant="ghost" asChild>
            <Link href="/login">Login</Link>
          </Button>
          <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Link href="/register">Get Started</Link>
          </Button>
        </div>
      </header>

      <main className="flex-grow">
        <section className="relative py-20 md:py-32 bg-secondary/50">
          <div className="container mx-auto px-4 text-center">
            <h1 className="font-headline text-4xl md:text-6xl font-bold tracking-tighter mb-4">
              Turn Waste into Opportunity
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              WasteZero is the smart platform connecting volunteers, NGOs, and communities for a cleaner, greener future. Join us to make a difference.
            </p>
            <Button size="lg" asChild>
              <Link href="/register">
                Join the Movement <ChevronRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="font-headline text-3xl md:text-4xl font-bold">Why WasteZero?</h2>
              <p className="text-muted-foreground mt-2">Everything you need to manage waste and volunteering effectively.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature) => (
                <Card key={feature.title} className="text-center hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="mx-auto bg-primary/10 text-primary p-3 rounded-full w-fit">
                      <feature.icon className="h-8 w-8" />
                    </div>
                    <CardTitle className="font-headline mt-4">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
        
        <section className="bg-secondary/50 py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="font-headline text-3xl md:text-4xl font-bold mb-4">Powered by People, Driven by Purpose</h2>
                <p className="text-muted-foreground mb-6">WasteZero empowers every individual and organization to take meaningful action. Whether you're a volunteer looking to contribute, an NGO organizing a cleanup, or an admin overseeing operations, our platform provides the tools you need for success.</p>
                <ul className="space-y-4">
                  <li className="flex items-start gap-3">
                    <Truck className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold">Efficient Pickup Scheduling</h3>
                      <p className="text-sm text-muted-foreground">Schedule and manage waste pickups with just a few clicks.</p>
                    </div>
                  </li>
                   <li className="flex items-start gap-3">
                    <MessageCircle className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold">Seamless Communication</h3>
                      <p className="text-sm text-muted-foreground">Real-time chat connects you with your team instantly.</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <LineChart className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold">Insightful Analytics</h3>
                      <p className="text-sm text-muted-foreground">Track your impact with comprehensive data and reports.</p>
                    </div>
                  </li>
                </ul>
              </div>
              {heroImage && (
                <div className="rounded-lg overflow-hidden shadow-xl aspect-video">
                  <Image
                    src={heroImage.imageUrl}
                    alt={heroImage.description}
                    width={600}
                    height={400}
                    data-ai-hint={heroImage.imageHint}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </div>
        </section>

      </main>

      <footer className="bg-background border-t">
        <div className="container mx-auto px-4 py-6 flex flex-col md:flex-row justify-between items-center text-sm text-muted-foreground">
          <p>&copy; {year || new Date().getFullYear()} WasteZero. All rights reserved.</p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <Link href="#" className="hover:text-primary">Privacy Policy</Link>
            <Link href="#" className="hover:text-primary">Terms of Service</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
