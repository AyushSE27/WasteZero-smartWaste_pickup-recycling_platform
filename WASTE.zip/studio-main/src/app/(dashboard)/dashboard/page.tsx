"use client";

import { useAuth } from "@/hooks/use-auth";
import { VolunteerDashboard } from "@/components/dashboard/volunteer-dashboard";
import { NgoDashboard } from "@/components/dashboard/ngo-dashboard";
import { AdminDashboard } from "@/components/dashboard/admin-dashboard";
import { Skeleton } from "@/components/ui/skeleton";

function DashboardSkeleton() {
    return (
        <div className="space-y-6">
            <div className="space-y-2">
                <Skeleton className="h-8 w-64" />
                <Skeleton className="h-4 w-96" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Skeleton className="h-28 rounded-lg" />
                <Skeleton className="h-28 rounded-lg" />
                <Skeleton className="h-28 rounded-lg" />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Skeleton className="h-96 rounded-lg lg:col-span-2" />
                <Skeleton className="h-96 rounded-lg lg:col-span-1" />
            </div>
        </div>
    )
}


export default function DashboardPage() {
  const { user, loading } = useAuth();

  if (loading) {
    return <DashboardSkeleton />
  }

  switch (user?.role) {
    case 'volunteer':
      return <VolunteerDashboard />;
    case 'ngo':
      return <NgoDashboard />;
    case 'admin':
      return <AdminDashboard />;
    default:
      return <DashboardSkeleton />;
  }
}
