import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, Truck } from "lucide-react";
import { format } from "date-fns";
import type { WasteType } from "@/lib/types";

const wasteTypes: WasteType[] = ['plastic', 'organic', 'e-waste', 'metal', 'paper', 'glass', 'textile'];

export default function SchedulePickupPage() {
  // In a real app, this would be a state
  const date = new Date();

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold font-headline">Schedule a Pickup</h1>
        <p className="text-muted-foreground">Arrange for your waste to be collected by our team.</p>
      </div>

      <Card>
        <CardHeader>
            <CardTitle>Pickup Details</CardTitle>
            <CardDescription>Please provide the details for your waste pickup.</CardDescription>
        </CardHeader>
        <CardContent>
            <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="waste-type">Waste Type</Label>
                        <Select>
                            <SelectTrigger id="waste-type">
                                <SelectValue placeholder="Select a waste type" />
                            </SelectTrigger>
                            <SelectContent>
                                {wasteTypes.map(type => (
                                    <SelectItem key={type} value={type} className="capitalize">{type}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="date">Pickup Date</Label>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button
                                variant={"outline"}
                                className="w-full justify-start text-left font-normal"
                                >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {date ? format(date, "PPP") : <span>Pick a date</span>}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar
                                mode="single"
                                selected={date}
                                // onSelect would update state in a real app
                                initialFocus
                                />
                            </PopoverContent>
                        </Popover>
                    </div>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="address">Pickup Address</Label>
                    <Input id="address" placeholder="e.g., 123 Green St, Eco City" />
                </div>
                 <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes (optional)</Label>
                    <Input id="notes" placeholder="e.g., Leave by the front gate" />
                </div>
                <div className="flex justify-end">
                    <Button type="submit">
                        <Truck className="mr-2 h-4 w-4" />
                        Confirm Pickup
                    </Button>
                </div>
            </form>
        </CardContent>
      </Card>
    </div>
  );
}
