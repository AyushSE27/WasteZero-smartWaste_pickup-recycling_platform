import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Send } from "lucide-react";
import { users, messages } from "@/lib/data";

const contacts = users.filter(u => u.role !== 'admin' && u.id !== 'user-2').slice(0, 5);
const selectedContact = users.find(u => u.id === 'user-6');
const currentUser = users.find(u => u.id === 'user-2');

export default function MessagesPage() {
    
    const getInitials = (name: string) => {
        return name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase();
    };

    return (
        <div className="h-[calc(100vh-10rem)]">
            <h1 className="text-3xl font-bold font-headline mb-4">Messages</h1>
            <Card className="h-full grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4">
                <div className="md:col-span-1 lg:col-span-1 border-r h-full flex flex-col">
                    <div className="p-4 border-b">
                        <div className="relative">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input placeholder="Search contacts..." className="pl-8" />
                        </div>
                    </div>
                    <div className="flex-grow overflow-auto">
                        {contacts.map(contact => (
                            <div key={contact.id} className={`flex items-center gap-3 p-3 cursor-pointer hover:bg-secondary ${contact.id === selectedContact?.id ? 'bg-secondary' : ''}`}>
                                <Avatar>
                                    <AvatarImage src={contact.avatarUrl} alt={contact.name} />
                                    <AvatarFallback>{getInitials(contact.name)}</AvatarFallback>
                                </Avatar>
                                <div className="flex-grow">
                                    <p className="font-semibold">{contact.name}</p>
                                    <p className="text-sm text-muted-foreground truncate">Sounds great, I just applied!</p>
                                </div>
                                <span className="text-xs text-muted-foreground">1h ago</span>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="md:col-span-2 lg:col-span-3 h-full flex flex-col">
                    {selectedContact && currentUser ? (
                        <>
                            <div className="flex items-center gap-3 p-4 border-b">
                                <Avatar>
                                    <AvatarImage src={selectedContact.avatarUrl} alt={selectedContact.name} />
                                    <AvatarFallback>{getInitials(selectedContact.name)}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <p className="font-semibold text-lg">{selectedContact.name}</p>
                                    <p className="text-sm text-green-500 flex items-center gap-1"><span className="h-2 w-2 bg-green-500 rounded-full"></span>Online</p>
                                </div>
                            </div>
                            <div className="flex-grow p-4 overflow-auto bg-slate-50 dark:bg-slate-900 space-y-4">
                                {messages.map(msg => (
                                    <div key={msg.id} className={`flex ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                                        <div className={`max-w-xs lg:max-w-md p-3 rounded-xl ${msg.senderId === currentUser.id ? 'bg-primary text-primary-foreground' : 'bg-background'}`}>
                                            <p>{msg.content}</p>
                                            <p className={`text-xs mt-1 ${msg.senderId === currentUser.id ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="p-4 border-t">
                                <div className="relative">
                                    <Input placeholder="Type a message..." className="pr-12" />
                                    <Button size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8">
                                        <Send className="h-4 w-4" />
                                    </Button>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-full">
                            <p className="text-muted-foreground">Select a contact to start messaging</p>
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
}
