"use client"

import * as React from "react"
import { Pie, PieChart, Cell } from "recharts"

import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent
} from "@/components/ui/chart"
import type { ChartConfig } from "@/components/ui/chart"

const chartData = [
  { wasteType: "Plastic", count: 275, fill: "var(--color-plastic)" },
  { wasteType: "Organic", count: 200, fill: "var(--color-organic)" },
  { wasteType: "E-Waste", count: 187, fill: "var(--color-ewaste)" },
  { wasteType: "Metal", count: 173, fill: "var(--color-metal)" },
  { wasteType: "Paper", count: 90, fill: "var(--color-paper)" },
]

const chartConfig = {
  count: {
    label: "Count",
  },
  plastic: {
    label: "Plastic",
    color: "hsl(var(--chart-1))",
  },
  organic: {
    label: "Organic",
    color: "hsl(var(--chart-2))",
  },
  ewaste: {
    label: "E-Waste",
    color: "hsl(var(--chart-3))",
  },
  metal: {
    label: "Metal",
    color: "hsl(var(--chart-4))",
  },
  paper: {
    label: "Paper",
    color: "hsl(var(--chart-5))",
  },
} satisfies ChartConfig

export function WasteDistributionChart() {
  return (
      <ChartContainer
        config={chartConfig}
        className="mx-auto aspect-square h-64"
      >
        <PieChart>
          <ChartTooltip
            cursor={false}
            content={<ChartTooltipContent hideLabel />}
          />
          <Pie
            data={chartData}
            dataKey="count"
            nameKey="wasteType"
            innerRadius={60}
            strokeWidth={5}
          >
             {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.fill} />
            ))}
          </Pie>
          <ChartLegend
            content={<ChartLegendContent nameKey="wasteType" />}
            className="-translate-y-2 flex-wrap gap-2 [&>*]:basis-1/4 [&>*]:justify-center"
          />
        </PieChart>
      </ChartContainer>
  )
}
