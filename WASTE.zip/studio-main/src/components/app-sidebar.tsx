
"use client"

import {
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Logo } from "@/components/logo";
import { useAuth } from "@/hooks/use-auth";
import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  LayoutDashboard,
  Recycle,
  PlusCircle,
  MessageSquare,
  Truck,
  User,
  Shield,
  LogOut,
  ScanLine
} from "lucide-react";
import { Button } from "./ui/button";

const commonLinks = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/opportunities", label: "Opportunities", icon: Recycle },
  { href: "/identify-waste", label: "Identify Waste", icon: ScanLine },
  { href: "/schedule-pickup", label: "Schedule Pickup", icon: Truck },
  { href: "/messages", label: "Messages", icon: MessageSquare },
  { href: "/profile", label: "My Profile", icon: User },
];

const ngoLinks = [
  { href: "/opportunities/create", label: "Create Opportunity", icon: PlusCircle },
];

const adminLinks = [
  { href: "/admin", label: "Admin Panel", icon: Shield },
];

export function AppSidebar() {
  const { user, logout } = useAuth();
  const pathname = usePathname();

  const isActive = (href: string) => {
    if (href === '/dashboard') return pathname === href;
    return pathname.startsWith(href);
  };
  
  const links = [
    ...commonLinks,
    ...(user?.role === 'ngo' ? ngoLinks : []),
    ...(user?.role === 'admin' ? adminLinks : []),
  ];

  return (
    <>
      <SidebarHeader>
        <Logo />
      </SidebarHeader>
      <SidebarContent className="p-2">
        <SidebarMenu>
          {links.map((link) => (
            <SidebarMenuItem key={link.href}>
              <SidebarMenuButton
                asChild
                isActive={isActive(link.href)}
                tooltip={{ children: link.label }}
              >
                <Link href={link.href}>
                  <link.icon />
                  <span>{link.label}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter>
        <Button variant="ghost" className="w-full justify-start gap-2" onClick={logout}>
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
        </Button>
      </SidebarFooter>
    </>
  );
}
