import { Leaf } from 'lucide-react';
import Link from 'next/link';
import { cn } from '@/lib/utils';

export function Logo({ className }: { className?: string }) {
  return (
    <Link href="/" className={cn('flex items-center gap-2 text-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm', className)}>
      <div className="bg-primary/20 p-2 rounded-lg">
        <Leaf className="h-5 w-5 text-primary" />
      </div>
      <span className="text-xl font-bold font-headline text-foreground">
        WasteZero
      </span>
    </Link>
  );
}
