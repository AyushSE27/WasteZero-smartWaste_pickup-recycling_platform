"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { applications, opportunities, users } from "@/lib/data";
import { useAuth } from "@/hooks/use-auth";
import Link from 'next/link';
import { ArrowRight, PlusCircle, Users, CheckCircle, Briefcase } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function NgoDashboard() {
  const { user } = useAuth();
  if (!user) return null;

  const ngoOpportunities = opportunities.filter(opp => opp.ngoId === user.id);
  const recentApplicants = applications
    .filter(app => ngoOpportunities.some(opp => opp.id === app.opportunityId))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const stats = {
    totalOpportunities: ngoOpportunities.length,
    totalApplicants: applications.filter(app => ngoOpportunities.some(opp => opp.id === app.opportunityId)).length,
    acceptedApplicants: applications.filter(app => ngoOpportunities.some(opp => opp.id === app.opportunityId) && app.status === 'accepted').length,
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-headline">NGO Dashboard</h1>
        <p className="text-muted-foreground">Manage your opportunities and volunteers.</p>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Your Opportunities</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{stats.totalOpportunities}</div>
            <p className="text-xs text-muted-foreground">Active and past listings</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Applicants</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{stats.totalApplicants}</div>
            <p className="text-xs text-muted-foreground">Across all your opportunities</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Accepted Volunteers</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{stats.acceptedApplicants}</div>
            <p className="text-xs text-muted-foreground">Ready to make a difference</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <div>
                <CardTitle>Your Opportunities</CardTitle>
                <CardDescription>A quick look at your active listings.</CardDescription>
            </div>
            <Button size="sm" asChild>
                <Link href="/opportunities/create">
                    <PlusCircle className="mr-2 h-4 w-4" /> Create
                </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-2">
            {ngoOpportunities.slice(0, 4).map(opp => (
              <div key={opp.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-secondary/50">
                <div>
                  <p className="font-semibold">{opp.title}</p>
                  <p className="text-sm text-muted-foreground">{opp.location}</p>
                </div>
                <Badge variant={opp.status === 'open' ? 'default' : 'secondary'} className="capitalize">{opp.status}</Badge>
              </div>
            ))}
            <Button variant="outline" className="w-full mt-4" asChild>
                <Link href="/opportunities">
                    Manage All Opportunities <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
            </Button>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Recent Applicants</CardTitle>
            <CardDescription>New volunteers interested in your cause.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-1">
            {recentApplicants.map(app => {
              const volunteer = users.find(u => u.id === app.volunteerId);
              const opportunity = opportunities.find(o => o.id === app.opportunityId);
              if (!volunteer || !opportunity) return null;
              return (
                <div key={app.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-secondary/50">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={volunteer.avatarUrl} alt={volunteer.name} />
                      <AvatarFallback>{volunteer.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{volunteer.name}</p>
                      <p className="text-sm text-muted-foreground">Applied for: {opportunity.title}</p>
                    </div>
                  </div>
                   <Button variant="outline" size="sm">View</Button>
                </div>
              );
            })}
             <Button variant="outline" className="w-full mt-4" asChild>
                <Link href="#">
                    View All Applicants <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
