"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { applications, opportunities } from "@/lib/data";
import { useAuth } from "@/hooks/use-auth";
import Link from 'next/link';
import { ArrowRight, Clock, Briefcase, CheckCheck } from "lucide-react";
import type { ApplicationStatus } from "@/lib/types";
import Image from "next/image";
import type { VariantProps } from "class-variance-authority";
import { badgeVariants } from "@/components/ui/badge";

// Using badge variants is better for theming than hardcoded colors.
const getStatusVariant = (status: ApplicationStatus): VariantProps<typeof badgeVariants>["variant"]=> {
  switch (status) {
    case 'accepted':
      return 'default'; // primary color (green in this theme)
    case 'pending':
      return 'secondary'; // muted color
    case 'rejected':
      return 'destructive';
    default:
      return 'secondary';
  }
};

export function VolunteerDashboard() {
  const { user } = useAuth();
  if (!user) return null;

  const userApplications = applications.filter(app => app.volunteerId === user.id).slice(0, 4);
  const suggestedOpportunities = opportunities.filter(opp => opp.status === 'open' && !userApplications.some(app => app.opportunityId === opp.id)).slice(0, 3);

  const stats = {
    applied: applications.filter(app => app.volunteerId === user.id).length,
    accepted: applications.filter(app => app.volunteerId === user.id && app.status === 'accepted').length,
    completedHours: applications.filter(app => app.volunteerId === user.id && app.status === 'accepted').reduce((acc, curr) => {
        const opp = opportunities.find(o => o.id === curr.opportunityId);
        return acc + (opp ? parseInt(opp.duration) : 0);
    }, 0),
  };

  return (
    <div className="space-y-6">
       <div>
        <h1 className="text-3xl font-bold font-headline">Volunteer Dashboard</h1>
        <p className="text-muted-foreground">Here's a summary of your volunteering activity and suggested opportunities.</p>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Opportunities Applied</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{stats.applied}</div>
            <p className="text-xs text-muted-foreground">Total applications sent</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Opportunities Accepted</CardTitle>
            <CheckCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{stats.accepted}</div>
            <p className="text-xs text-muted-foreground">Your approved applications</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Hours Volunteered</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{stats.completedHours}</div>
            <p className="text-xs text-muted-foreground">Estimated total impact</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Suggested Opportunities</CardTitle>
            <CardDescription>Based on your skills and location.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {suggestedOpportunities.map(opp => {
              const opportunity = opportunities.find(o => o.id === opp.id);
              if (!opportunity) return null;
              return (
                <div key={opp.id} className="flex items-center gap-4 p-2 rounded-lg hover:bg-secondary/50 transition-colors">
                  <Image src={opportunity.imageUrl} alt={opportunity.title} width={80} height={80} className="rounded-md object-cover w-20 h-20" />
                  <div className="flex-grow">
                    <p className="font-semibold">{opportunity.title}</p>
                    <p className="text-sm text-muted-foreground">{opportunity.location}</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                        {opportunity.requiredSkills.slice(0,2).map(skill => <Badge key={skill} variant="outline">{skill}</Badge>)}
                    </div>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/opportunities`}>View <ArrowRight className="ml-2 h-4 w-4" /></Link>
                  </Button>
                </div>
              );
            })}
             <Button variant="ghost" className="w-full mt-2" asChild>
                <Link href="/opportunities">
                    Explore All Opportunities <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
            </Button>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Recent Applications</CardTitle>
            <CardDescription>Track the status of your applications.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {userApplications.map(app => {
              const opportunity = opportunities.find(o => o.id === app.opportunityId);
              if (!opportunity) return null;
              return (
                <div key={app.id} className="flex items-start justify-between p-2 rounded-lg hover:bg-secondary/50 transition-colors">
                  <div>
                    <p className="font-semibold">{opportunity.title}</p>
                    <p className="text-sm text-muted-foreground">{new Date(app.createdAt).toLocaleDateString()}</p>
                  </div>
                  <Badge variant={getStatusVariant(app.status)} className="capitalize">
                    {app.status}
                  </Badge>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
